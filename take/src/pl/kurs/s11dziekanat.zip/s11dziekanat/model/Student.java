package pl.kurs.s11dziekanat.model;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity(name="Studenci")
public class Student {

	
	@Id
	@GeneratedValue
	private Long id;
	
	@Column(name = "imie", length = 65535)
	private String imie;
	 
	@Column(name = "nazwisko", length = 65535)
	private String nazwisko;
	
	@Column(name = "data_urodzenia", nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataUrodzenia;

	public Student() {
		
	}
	
	public Student(Long id, String imie, String nazwisko, Date date) {
		super();
		this.id = id;
		this.imie = imie;
		this.nazwisko = nazwisko;
		this.dataUrodzenia = date;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getImie() {
		return imie;
	}

	public void setImie(String imie) {
		this.imie = imie;
	}

	public String getNazwisko() {
		return nazwisko;
	}

	public void setNazwisko(String nazwisko) {
		this.nazwisko = nazwisko;
	}

	public Date getDataUrodzenia() {
		return dataUrodzenia;
	}

	public void setDataUrodzenia(Date dataUrodzenia) {
		this.dataUrodzenia = dataUrodzenia;
	}

	@Override
	public int hashCode() {
		return Objects.hash(dataUrodzenia, id, imie, nazwisko);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return Objects.equals(dataUrodzenia, other.dataUrodzenia) && Objects.equals(id, other.id) && Objects.equals(imie, other.imie)
				&& Objects.equals(nazwisko, other.nazwisko);
	}


	
	
	
	
}
