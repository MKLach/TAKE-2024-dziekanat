package pl.kurs.s11dziekanat.model;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity(name = "Przedmioty")
public class Przedmiot {

	@Id
	@GeneratedValue
	private Long id;
	
	
	@Column(nullable = true, length = 65535)
	private String nazwa;
	
	
	@ManyToMany
	@JoinTable(
			name = "PROWADZACY_PRZEDMIOTY", 
			joinColumns = @JoinColumn(name="prowadzacy_id", referencedColumnName = "id"), 
			inverseJoinColumns = @JoinColumn(name="przedmiot_id", referencedColumnName = "id"))
	private Set<Prowadzacy> prowadzacy;

	
	public Przedmiot() {
		
	}
	
	public Przedmiot(Long id, String nazwa) {
		super();
		this.id = id;
		this.nazwa = nazwa;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getNazwa() {
		return nazwa;
	}


	public void setNazwa(String nazwa) {
		this.nazwa = nazwa;
	}
	
	public void addProwadzacy(Prowadzacy prowadzacy) {
		
		if(this.prowadzacy == null) {
			this.prowadzacy = new HashSet<Prowadzacy>();
		}
		
		this.prowadzacy.add(prowadzacy);
		
	}
	
	public void removeProwadzacy(Prowadzacy prowadzacy) {
		
		if(this.prowadzacy == null) {
			this.prowadzacy = new HashSet<Prowadzacy>();
			return;
		}
		
		this.prowadzacy.remove(prowadzacy);
		
	}

	
	public Set<Prowadzacy> getProwdzacy(){
		
		return prowadzacy;
	}
	

	@Override
	public int hashCode() {
		return Objects.hash(id, nazwa, prowadzacy);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Przedmiot other = (Przedmiot) obj;
		return Objects.equals(id, other.id) && Objects.equals(nazwa, other.nazwa) && Objects.equals(prowadzacy, other.prowadzacy);
	}


	@Override
	public String toString() {
		return "Przedmiot [id=" + id + ", nazwa=" + nazwa + ", prowadzacy=" + prowadzacy + "]";
	}
	
	
	
}

