package pl.kurs.s11dziekanat.model;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity(name="Oceny")
public class Ocena {

	@Id
	@GeneratedValue
	private Long id;
	
	@Column(name="ocena")
	private double ocena;
	
	@Column(name="komentarz", length = 65535)
	private String komentarz;
	
	
	@ManyToOne
	@JoinColumn(name="student_id")
	private Student student;
	
	@ManyToOne
	@JoinColumn(name="prowadzacy_id")
	private Prowadzacy prowadzacy;
	
	@ManyToOne
	@JoinColumn(name="przedmiot_id")
	private Przedmiot przedmiot;
	
	

	public Ocena(Long id, double ocena, String komentarz) {
		super();
		this.id = id;
		this.ocena = ocena;
		this.komentarz = komentarz;
	}

	public Long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public double getOcena() {
		return ocena;
	}

	public void setOcena(double ocena) {
		this.ocena = ocena;
	}

	public String getKomentarz() {
		return komentarz;
	}

	public void setKomentarz(String komentarz) {
		this.komentarz = komentarz;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Prowadzacy getProwadzacy() {
		return prowadzacy;
	}

	public void setProwadzacy(Prowadzacy prowadzacy) {
		this.prowadzacy = prowadzacy;
	}

	public Przedmiot getPrzedmiot() {
		return przedmiot;
	}

	public void setPrzedmiot(Przedmiot przedmiot) {
		this.przedmiot = przedmiot;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, komentarz, ocena, prowadzacy, przedmiot, student);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ocena other = (Ocena) obj;
		return Objects.equals(id, other.id) && Objects.equals(komentarz, other.komentarz)
				&& Double.doubleToLongBits(ocena) == Double.doubleToLongBits(other.ocena)
				&& Objects.equals(prowadzacy, other.prowadzacy) && Objects.equals(przedmiot, other.przedmiot)
				&& Objects.equals(student, other.student);
	}
	
	
}
