package pl.kurs.s11dziekanat.model;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity(name="Prowadzacy")
public class Prowadzacy {

	
	@Id
	@GeneratedValue
	private Long id;
	
	@Column(name = "imie",length = 65535)
	private String imie;
	
	@Column(name = "nazwisko", length = 65535)
	private String nazwisko;
	
	@Column(name = "tytul", length = 65535)
	private String tytul;

	
	@ManyToMany
	@JoinTable(
			name = "PROWADZACY_PRZEDMIOTY", 
			joinColumns = @JoinColumn(name="prowadzacy_id", referencedColumnName = "id"), 
			inverseJoinColumns = @JoinColumn(name="przedmiot_id", referencedColumnName = "id"))
	private Set<Przedmiot> przedmioty;
	
	@OneToMany(mappedBy = "prowadzacy")
	private Set<Ocena> oceny;
	
	public Prowadzacy(){
		
	}
	
	public Prowadzacy(Long id, String imie, String nazwisko, String tytul) {
		super();
		this.id = id;
		this.imie = imie;
		this.nazwisko = nazwisko;
		this.tytul = tytul;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getImie() {
		return imie;
	}

	public void setImie(String imie) {
		this.imie = imie;
	}

	public String getNazwisko() {
		return nazwisko;
	}

	public void setNazwisko(String nazwisko) {
		this.nazwisko = nazwisko;
	}

	public String getTytul() {
		return tytul;
	}

	public void setTytul(String tytul) {
		this.tytul = tytul;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, imie, nazwisko, przedmioty, tytul);
	}

	public Set<Przedmiot> getPrzedmioty() {
		return przedmioty;
	}

	public void setPrzedmioty(Set<Przedmiot> przedmioty) {
		this.przedmioty = przedmioty;
	}
	
	public void addPrzedmioty(Przedmiot przedmioty) {
		if(this.przedmioty == null) {
			this.przedmioty = new HashSet<Przedmiot>();
		}
		
		this.przedmioty.add(przedmioty);
		
	}
	
	public void removePrzedmioty(Przedmiot przedmioty) {
		if(this.przedmioty == null) {
			this.przedmioty = new HashSet<Przedmiot>();
			return;
		}
		
		this.przedmioty.remove(przedmioty);
		
	}

	public Set<Ocena> getOceny() {
		return oceny;
	}

	public void setOceny(Set<Ocena> oceny) {
		this.oceny = oceny;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Prowadzacy other = (Prowadzacy) obj;
		return Objects.equals(id, other.id) && Objects.equals(imie, other.imie) && Objects.equals(nazwisko, other.nazwisko)
				&& Objects.equals(przedmioty, other.przedmioty) && Objects.equals(tytul, other.tytul);
	}

	@Override
	public String toString() {
		return "Prowadzacy [id=" + id + ", imie=" + imie + ", nazwisko=" + nazwisko + ", tytul=" + tytul
				+ ", przedmioty=" + przedmioty + "]";
	}
	
	
	
	
}
